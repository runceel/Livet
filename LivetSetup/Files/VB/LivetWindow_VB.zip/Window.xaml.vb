﻿Class $safeitemname$

End Class
