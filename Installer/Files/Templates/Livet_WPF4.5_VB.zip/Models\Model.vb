﻿Namespace Models
	Friend Class Model
	    Inherits NotificationObject

	    'NotificationObjectはプロパティ変更通知の仕組みを実装したオブジェクトです。
	    
	End Class
End Namespace
